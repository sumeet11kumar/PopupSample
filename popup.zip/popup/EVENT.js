﻿$(window).load(function () {
    var session = $("#hdnSessionStatus").val();
    if (session == "N") {
        var d = new Date();
        $("#MyPopup .modal-body").html("Date&Time of Popup: " + d.toString());
        $("#MyPopup").modal("show");
        UpdateSessionValue();
    }
});

function UpdateSessionValue(){
    //$(function () {
    //    $("#btnSubmit").click(function () {
    $.ajax({
        type: "POST",
        url: "page1.aspx/SendParameters",
        data: "{name: 'Y'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (r) {
        }
    });
    $("#btnClosePopup").click(function () {
        $("#MyPopup").modal("hide");
    });
}